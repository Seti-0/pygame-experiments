# This game was made for learning purposes,
# hence the abundance of unnecessary comments
# all over the place

import time
import math

import pygame

from PodSixNet.Connection import ConnectionListener, connection

# Constants for state
CONNECTING = "JOINING"
CONNECTED = "CONNECTED"
IN_GAME = "IN_GAME"
DISCONNECTED = "DISCONNECTED"

# Status messages
MESSAGES = {}
MESSAGES[CONNECTING] = "Searching for game..."
MESSAGES[CONNECTED] = "Joined game as RED player."
MESSAGES[DISCONNECTED] = "Disconnected"

# Constants for colors. These should be the same
# as for the server
NONE = "NONE"
BLUE = "BLUE"
RED = "RED"

# Extra constant for images
HOVER = "HOVER"

class BoxesClient(ConnectionListener):

    def __init__(self):
        # Init pygame
        pygame.init()
        
        # Create the window
        width, height = 432, 530
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption("Boxes")

        # Misc init - the last of the three includes
        # images and fonts, for exmaple
        self.clock = pygame.time.Clock()
        self.initMouse()
        self.initGraphics()

        # Start trying to connect.
        self.Connect(("localhost", 8888))
        self.state = CONNECTING

        # Don't setup the board just yet. We'll show
        # a connection screen until such time as a game
        # has been started

    def initMouse(self):
        # Data specifying which line (if any)
        # is currently under the mouse
        self.hover_h = False
        self.hover_v = False
        self.hover_i = 0
        self.hover_j = 0

        # This is used to prevent multiple mouse up 
        # events firing for a single click
        self.mouse_up_lock = False

    def initGraphics(self):
        # For drawing grid points
        self.image_dot = pygame.image.load("dot.png")

        # For drawing horizontal lines
        self.image_h = {}
        self.image_h[NONE] = pygame.image.load("line.png")
        self.image_h[HOVER] = pygame.image.load("line_yellow.png")
        self.image_h[BLUE] = pygame.image.load("line_blue.png")
        self.image_h[RED] = pygame.image.load("line_red.png")

        # For drawing vertical lines
        self.image_v = {}
        for state in [NONE, HOVER, BLUE, RED]:
            self.image_v[state] = pygame.transform.rotate(self.image_h[state], -90)

        # Cell length 
        # (this is based on the segment image size of 64x4)
        self.L = 64 + 4

        # A general constant for margins
        self.margin = 10

        # Fonts. Large is used for score and status messages.
        # Medium is used for the turn indicator, small is used to label
        # the scores
        self.font_medium = pygame.font.SysFont(None, 32)
        self.font_small = pygame.font.SysFont(None, 16)
        self.font_large = pygame.font.SysFont(None, 64)

    def Network(self, data):
        # This method is called when the incoming data has no action,
        # or an action that does not have a corresponding method
        print("Data Received: "+str(data))

    def Network_onJoined(self, data):
        # This means that this client was the first to join the game.
        # The game will not start until a second player has joined
        print("Joined game! Waiting for player 2.")
        self.state = CONNECTED

    def Network_disconnected(self, data):
        self.state = DISCONNECTED
        self.resetGame(NONE)

    def Network_startGame(self, data):
        # Two players have joined, the game may start now
        print("Data: "+str(data))

        # There is no guarantee that the incoming message is 
        # correctly formed.
        error = None

        if "color" in data:
            color = data["color"]
            if not (color == BLUE or color == RED):
                # It might have an unrecognized color
                error = f"Unrecognized color: {color}"
        else:
            # Or it might not have a color value at all
            error = "Missing data: color"

        if error is not None:
            print(error)
            self.state = DISCONNECTED
            self.resetGame(NONE)
        else:
            # If all goes well, reset the board
            # and start the game
            print("Game started!")
            self.state = IN_GAME
            self.resetGame(color)

    def resetGame(self, local_color):
        # A local copy of the score. This does not affect the
        # actual score of the game, which is stored server-side
        self.local_score = 0
        self.remote_score = 0

        # Colors (for score display purposes only,
        # the actual logic regarding color is handled server-side)
        self.local_color = local_color

        # The server will assign a turn to us when the time is right
        self.has_turn = False

        # A local copy of the board. This does not affect the
        # actual the state of the game, which is stored server side
        self.colors_h = [[NONE for y in range(7)] for x in range(6)]
        self.colors_v = [[NONE for y in range(6)] for x in range(7)]

        # Red gets the first turn
        self.has_turn = self.local_color == RED

    def Network_placeLine(self, data):
        # Update the local copy of the board with info from the
        # server. Ignore the message if its format is unfamiliar.
        try:
            color = str(data["color"])
            i = int(data["i"])
            j = int(data["j"])
            horizontal = bool(int(data["horizontal"]))
        except ValueError as e:
            # A ValueError is expected if a conversion to int fails
            print("Unable to parse placeLine message: " + str(e))
            return
        except NameError: 
            # A NameError is expected if a key is missing
            print("Unable to parse placeLine message: " + str(e))
            return

        if not color in [BLUE, RED]:
            print("Unrecognized color: "+color)
            return

        if horizontal:
            limit = 5, 6
        else:
            limit = 6, 5

        if i < 0 or i >= limit[0] or j < 0 or j >= limit[1]:
            print("Index out of range")
            return

        if horizontal:
            self.colors_h[i][j] = color
        else:
            self.colors_v[i][j] = color

        # If everything goes well, set the turn accordingly
        if color == self.local_color:
            self.has_turn = False
        else:
            self.has_turn = True

    def Network_endTurn(self, data):
        # This will prevent mouse hover and clicks
        self.has_turn = False

    def update(self):
        # PodSizeNet update methods
        connection.Pump()
        self.Pump()
        
        # Pygame update method
        self.clock.tick(60)

        # Clear the screen (fill it with black)
        self.screen.fill(0)

        # Lookg through events that occured since the last frame
        for event in pygame.event.get():
            
            # This fires if the quit button is pressed
            if event.type == pygame.QUIT:
                exit(0)

            # Note: this seems to fire multiple times per mouse
            # click, so to avoid awkwardness the mouse_up_lock variable is used
            if event.type == pygame.MOUSEBUTTONUP:
                self.mouse_up = not self.mouse_up_lock
                self.mouse_up_lock = True
            else:
                self.mouse_up = False
                self.mouse_up_lock = False      

        if self.state == IN_GAME:
            self.updateHover()
            # Strictly speaking, the extra check for has_turn is not needed,
            # since updateHover will clear the current hover info if has_turn is false
            if self.has_turn and self.mouse_up:
                self.addLine()

            self.drawBoard()
            self.drawHUD()
        else:
            # If we aren't in-game, draw some text
            # to inform the user of the current status
            self.drawStatusScreen()

        # Replace the previous frame onscreen with the
        # new one just drawn.
        pygame.display.flip()

    def drawStatusScreen(self):
        x = y = self.margin
        color = (255, 255, 255)

        # Draw the current status message
        label = self.font_small.render(MESSAGES[self.state], 0, color)
        self.screen.blit(label, [x,y])

    def addLine(self):
        target = None

        if self.hover_h:
            target = self.colors_h
        
        elif self.hover_v:
            target = self.colors_v

        if target is not None:
            if target[self.hover_i][self.hover_j] == NONE:
                connection.Send({
                    "action": "requestPlace", 
                    "i": self.hover_i,
                    "j": self.hover_j,
                    "horizontal": self.hover_h
                    })

    def updateHover(self):
        # Clear hover from last iteration
        self.hover_h = False
        self.hover_v = False

        # Only allow hover (and thus placing) 
        # if it is our turn
        if not self.has_turn:
            return

        # Get and convert mouse coords to coords local
        # to the board
        x, y = pygame.mouse.get_pos()
        x = x - self.margin
        y = y - self.margin

        # Current cell index
        self.hover_i = int(x/self.L)
        self.hover_j = int(y/self.L)

        # Coordinate local to current cell
        local_x = (x % self.L) / self.L
        local_y = (y % self.L) / self.L

        # What region of the cell are we in?
        #  a | b
        #  1 | 1   ...  bottom (h) (y:+1)
        #  1 | 0   ...  right (v) (x:+1)
        #  0 | 1   ...  left (v)
        #  0 | 0   ...  top (h)

        a = local_y < local_x
        b = local_y < 1 - local_x

        if a and b:
            self.hover_h = True
        elif a:
            self.hover_i += 1
            self.hover_v = True
        elif b:
            self.hover_v = True
        else:
            self.hover_j += 1
            self.hover_h = True

        # Constrain indices

        if self.hover_h:
            limit = 5, 6
        else:
            limit = 6, 5

        self.hover_i = max(0, min(self.hover_i, limit[0]))
        self.hover_j = max(0, min(self.hover_j, limit[1]))

    def drawBoard(self):

        # Horizontal lines first. 
        
        for i in range(6):
            for j in range(7):
                
                # 64 pixels per segment, plus the gap of 4 pixels

                state = self.colors_h[i][j]
                
                if state == NONE and self.hover_h:
                    if self.hover_i == i and self.hover_j == j:
                        state = HOVER
                
                image = self.image_h[state]

                # Note the extra gap in the x-coord
                x = self.margin + i * 64 + (i + 1) * 4
                y = self.margin + j * (64 + 4)
                self.screen.blit(image, [x, y])

        # Vertical lines next. 

        for i in range(7):
            for j in range(6):

                state = self.colors_v[i][j]
                
                if state == NONE and self.hover_v:
                    if self.hover_i == i and self.hover_j == j:
                        state = HOVER
                
                image = self.image_v[state]

                # The extra gap is now in the y-coord
                x = self.margin + i * (64 + 4) 
                y = self.margin + j * 64 + (j + 1) * 4
                self.screen.blit(image, [x, y])

        # Lastly, the grid points

        for i in range(7):
            for j in range(7):
                x = self.margin - 3 + i * (64 + 4)
                y = self.margin - 3 + j * (64 + 4)
                self.screen.blit(self.image_dot, [x,y])

    def drawHUD(self):

        red = (255,100,120)
        blue = (110, 120, 255)

        # Whose turn is it?
        if (self.local_color == RED) == self.has_turn:
            text = "Red's Turn"
            color = red
        else:
            text = "Blue's Turn"
            color = blue

        x = self.margin
        y = self.margin * 3 + self.L * 6
        label = self.font_medium.render(text, 1, color)
        self.screen.blit(label, [x,y])

        # The score:

        color = (255, 255, 255)

        y += 32
        label = self.font_small.render("Blue score:", 1, color)
        self.screen.blit(label, [x, y])

        y += 16
        label = self.font_large.render("3", 1, blue)
        self.screen.blit(label, [x, y])

        x = 360
        y -= 16
        label = self.font_small.render("Red score:", 1, color)
        self.screen.blit(label, [x, y])

        x = 400
        y += 16
        label = self.font_large.render("9", 1, red)
        self.screen.blit(label, [x, y])

game = BoxesClient()

while True:
    game.update()
